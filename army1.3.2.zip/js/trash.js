// function saveteam(event, treeId, treeNode) {
//     app.set("armyteam", zTree.getNodes())
// }
// var setting = {
//     edit: {
//         enable: true,
//         editNameSelectAll: true
//     },
//     view: {
//         dblClickExpand: false
//     },
//     data: {
//         simpleData: {
//             enable: true
//         }
//     },
//     callback: {
//         onClick: onClick,
//         onRightClick: OnRightClick,
//         beforeDrag: beforeDrag,
//         onDrag: savemember,
//         onDrop: savemember,
//         beforeAsync: savemember,
//         beforeCheck: savemember,
//         beforeClick: savemember,
//         beforeCollapse: savemember,
//         beforeDblClick: savemember,
//         beforeEditName: savemember,
//         beforeExpand: savemember,
//         beforeRemove: savemember,
//         beforeRename: savemember,
//         onAsyncError: savemember,
//         onAsyncSuccess: savemember,
//         onCheck: savemember,
//         onCollapse: savemember,
//         onDblClick: savemember,
//         onDragMove: savemember,
//         onExpand: savemember,
//         onRemove: savemember,
//         onRename: savemember,
//     }
// };