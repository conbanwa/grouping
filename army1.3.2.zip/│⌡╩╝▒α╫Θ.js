var armyteaminit = [{
    id: 1,
    pId: 0,
    name: "抵近侦察组",
    open: true,
}, {
    id: 11,
    pId: 1,
    name: "侦察组 1-1"
}, {
    id: 12,
    pId: 1,
    name: "侦察组 1-2"
}, {
    id: 13,
    pId: 1,
    name: "侦察组 1-3"
}, {
    id: 2,
    pId: 0,
    name: "侦察大队 2",
    open: true,
}, {
    id: 21,
    pId: 2,
    name: "侦察组 2-1"
}, {
    id: 22,
    pId: 2,
    name: "分队 2-2"
}, {
    id: 23,
    pId: 2,
    name: "侦察组 2-3"
}, {
    id: 3,
    pId: 0,
    name: "空中侦察队",
    open: true,
}, {
    id: 31,
    pId: 3,
    name: "侦察组 3-1"
}, {
    id: 32,
    pId: 3,
    name: "侦察组 3-2"
}, {
    id: 33,
    pId: 3,
    name: "侦察组 3-3"
}]